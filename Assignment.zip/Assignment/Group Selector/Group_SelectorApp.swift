//
//  Group_SelectorApp.swift
//  Group Selector
//
//  Created by Adrian Devezin on 11/9/21.
//

import SwiftUI

@main
struct Group_SelectorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
